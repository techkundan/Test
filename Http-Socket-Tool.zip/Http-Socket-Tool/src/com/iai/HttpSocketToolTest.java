package com.iai;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class HttpSocketToolTest extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Http & Socket Connection Tool");

		// Create the registration form grid pane
		GridPane httpGridPane = createHttpGridPane();
		GridPane socketGridPane = createSocketGridPane();

		// Add UI controls to the Http form grid pane
		addHttpUIControls(httpGridPane);
		// Add UI controls to the Socket form grid pane
		addSocketUIControls(socketGridPane);

		TabPane tabPane = new TabPane();

		Tab httpTab = new Tab("HTTP", httpGridPane);
		Tab socketTab = new Tab("Socket", socketGridPane);
		tabPane.getTabs().add(httpTab);
		tabPane.getTabs().add(socketTab);
		tabPane.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);
		// VBox vBox = new VBox(tabPane);

		// Create a scene with registration form grid pane as the root node
		Scene scene = new Scene(tabPane, 700, 550);
		// Set the scene in primary stage
		primaryStage.setScene(scene);

		primaryStage.show();
	}

	private GridPane createHttpGridPane() {
		// Instantiate a new Grid Pane
		GridPane gridPane = new GridPane();

		// Position the pane at the center of the screen, both vertically and
		// horizontally
		gridPane.setAlignment(Pos.CENTER);

		// Set a padding of 20px on each side
		gridPane.setPadding(new Insets(0, 10, 10, 10));

		// Set the horizontal gap between columns
		gridPane.setHgap(10);

		// Set the vertical gap between rows
		gridPane.setVgap(10);

		// Add Column Constraints
		// columnOneConstraints will be applied to all the nodes placed in column one.
		ColumnConstraints columnOneConstraints = new ColumnConstraints(100, 100, Double.MAX_VALUE);
		columnOneConstraints.setHalignment(HPos.RIGHT);

		// columnTwoConstraints will be applied to all the nodes placed in column two.
		ColumnConstraints columnTwoConstrains = new ColumnConstraints(200, 200, Double.MAX_VALUE);
		columnTwoConstrains.setHgrow(Priority.ALWAYS);

		gridPane.getColumnConstraints().addAll(columnOneConstraints, columnTwoConstrains);

		return gridPane;
	}

	private GridPane createSocketGridPane() {
		// Instantiate a new Grid Pane
		GridPane gridPane = new GridPane();

		// Position the pane at the center of the screen, both vertically and
		// horizontally
		gridPane.setAlignment(Pos.CENTER);

		// Set a padding of 20px on each side
		gridPane.setPadding(new Insets(0, 10, 10, 10));

		// Set the horizontal gap between columns
		gridPane.setHgap(10);

		// Set the vertical gap between rows
		gridPane.setVgap(10);

		// Add Column Constraints
		// columnOneConstraints will be applied to all the nodes placed in column one.
		ColumnConstraints columnOneConstraints = new ColumnConstraints(100, 100, Double.MAX_VALUE);
		columnOneConstraints.setHalignment(HPos.RIGHT);

		// columnTwoConstraints will be applied to all the nodes placed in column two.
		ColumnConstraints columnTwoConstrains = new ColumnConstraints(200, 200, Double.MAX_VALUE);
		columnTwoConstrains.setHgrow(Priority.ALWAYS);

		gridPane.getColumnConstraints().addAll(columnOneConstraints, columnTwoConstrains);

		return gridPane;
	}

	private void addHttpUIControls(GridPane gridPane) {
		// Add Header
		Label headerLabel = new Label("Http Tool");
		headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
		gridPane.add(headerLabel, 0, 0, 3, 1);
		GridPane.setHalignment(headerLabel, HPos.CENTER);
		GridPane.setMargin(headerLabel, new Insets(10, 0, 5, 0));

		// Add URL Label
		Label httpUrlLabel = new Label("URL: ");
		gridPane.add(httpUrlLabel, 0, 1);

		// Add URL Text Field
		TextField httpUrlTextField = new TextField();
		httpUrlTextField.setPrefHeight(40);
		gridPane.add(httpUrlTextField, 1, 1);

		// Add Http Method Combo Box
		String httpMethod[] = { "GET", "POST", "PUT", "DELETE", "HEAD" };
		final ComboBox httpComboBox = new ComboBox(FXCollections.observableArrayList(httpMethod));
		httpComboBox.setValue("POST");
		httpComboBox.setPrefHeight(40);
		gridPane.add(httpComboBox, 2, 1);

		// Add HEADER Label
		Label httpHeaderLabel = new Label("HEADER: ");
		gridPane.add(httpHeaderLabel, 0, 2);

		// Add Key Label
		Label httpKeyLabel = new Label("Key: ");
		gridPane.add(httpKeyLabel, 0, 3);

		// Add Key Text Field
		TextField httpKeyTxtField = new TextField();
		httpKeyTxtField.setPrefHeight(40);
		gridPane.add(httpKeyTxtField, 1, 3);

		// Add Value Label
		Label httpValueLabel = new Label("Value: ");
		gridPane.add(httpValueLabel, 0, 4);

		// Add Value Text Field
		TextField httpValueTxtField = new TextField();
		httpValueTxtField.setPrefHeight(40);
		gridPane.add(httpValueTxtField, 1, 4);

		// Add Request Label
		Label httpReqLabel = new Label("Request: ");
		gridPane.add(httpReqLabel, 0, 5);

		// Add Request Text Area Field
		TextArea httpReqTxtArea = new TextArea();
		httpReqTxtArea.setPrefHeight(180);
		gridPane.add(httpReqTxtArea, 1, 5);

		// Add Submit Button
		Button submitButton = new Button("SEND");
		submitButton.setPrefHeight(80);
		submitButton.setDefaultButton(true);
		submitButton.setPrefWidth(200);
		gridPane.add(submitButton, 0, 6, 3, 1);
		GridPane.setHalignment(submitButton, HPos.CENTER);
		GridPane.setMargin(submitButton, new Insets(20, 0, 20, 0));

		// Add Response Label
		Label httpResLabel = new Label("Response: ");
		gridPane.add(httpResLabel, 0, 7);

		// Add Response Text Area Field
		TextArea httpResTxtArea = new TextArea();
		httpResTxtArea.setWrapText(true);
		httpResTxtArea.setPrefHeight(180);
		gridPane.add(httpResTxtArea, 1, 7);

		submitButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				String url = httpUrlTextField.getText();
				String httpMethod = (String) httpComboBox.getValue();
				String key = httpKeyTxtField.getText();
				String value = httpValueTxtField.getText();
				String httpReq = httpReqTxtArea.getText();
				String httpRes = "";

				if (url.isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter your URL");
				}

				if (key.isEmpty() && value.isEmpty()) {
					key = "Content-Type";
					value = "text-plain";
				}
				if (httpReq.isEmpty()) {
					httpReq = "";
				}
				RequestBody body = null;
				try {
					OkHttpClient client = new OkHttpClient().newBuilder().build();
					if (!httpMethod.equals("GET")) {
						MediaType mediaType = MediaType.parse(value);
						body = RequestBody.create(mediaType, httpReq);
					}
					Request request = new Request.Builder().url(url).method(httpMethod, body).addHeader(key, value)
							.addHeader("cache-control", "no-cache").build();
					System.out.println("URL: " + url + " HttpMethod: " + httpMethod + " \nRequest: " + httpReq);

					Response response = client.newCall(request).execute();
					// Do somthing with the Response
					httpRes = response.body().string();
					System.out.println(httpRes);
					httpResTxtArea.setText(httpRes);

				} catch (IOException ioe) {
					httpRes = ioe.getMessage();
					httpResTxtArea.setText(httpRes);
					ioe.printStackTrace();
				} catch (Exception e) {
					httpRes = e.getMessage();
					httpResTxtArea.setText(httpRes);
					e.printStackTrace();
				}

				// showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(),
				// "Registration Successful!", "Welcome " + httpUrlTextField.getText());

			}
		});
	}

	private void addSocketUIControls(GridPane gridPane) {

		// Add Header
		Label socketHeaderLabel = new Label("Socket Tool");
		socketHeaderLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
		gridPane.add(socketHeaderLabel, 0, 0, 4, 1);
		GridPane.setHalignment(socketHeaderLabel, HPos.CENTER);
		GridPane.setMargin(socketHeaderLabel, new Insets(10, 0, 5, 0));

		// Add IP Label
		Label socketIPLabel = new Label("IP: ");
		gridPane.add(socketIPLabel, 0, 1);

		// Add URL Text Field
		TextField socketIPTextField = new TextField();
		socketIPTextField.setPrefHeight(40);
		gridPane.add(socketIPTextField, 1, 1);

		// Add PORT Label
		Label socketPortLabel = new Label("PORT: ");
		gridPane.add(socketPortLabel, 2, 1);

		// Add URL Text Field
		TextField socketPORTTextField = new TextField();
		socketIPTextField.setPrefHeight(40);
		gridPane.add(socketPORTTextField, 3, 1);

		// Add Request Label
		Label socketReqLabel = new Label("Request: ");
		gridPane.add(socketReqLabel, 0, 2);

		// Add Request Text Area Field
		TextArea socketReqTxtArea = new TextArea();
		socketReqTxtArea.setPrefHeight(180);
		gridPane.add(socketReqTxtArea, 1, 2);

		// Add Socket Submit Button
		Button submitButton = new Button("SEND");
		submitButton.setPrefHeight(40);
		submitButton.setDefaultButton(true);
		submitButton.setPrefWidth(200);
		gridPane.add(submitButton, 1, 3, 1, 1);
		GridPane.setHalignment(submitButton, HPos.CENTER);
		GridPane.setMargin(submitButton, new Insets(20, 0, 20, 0));

		// Add Response Label
		Label socketResLabel = new Label("Response: ");
		gridPane.add(socketResLabel, 0, 4);

		// Add Response Text Area Field
		TextArea socketResTxtArea = new TextArea();
		socketResTxtArea.setWrapText(true);
		socketResTxtArea.setPrefHeight(180);
		gridPane.add(socketResTxtArea, 1, 4);

		submitButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				String ip = socketIPTextField.getText();
				String port =socketPORTTextField.getText();
				String socketReq = socketReqTxtArea.getText();
				String socketRes="";
				
				if (ip.isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter your IP");
				}

				if (port.isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter your Port");
				}

				if (socketReq.isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter a Request");
				}
				
				 
			        String domainName = "";
			        
			        try {
			        	Socket socket = new Socket(ip,Integer.parseInt(port));
			        	
			            OutputStream output = socket.getOutputStream();
			            PrintWriter writer = new PrintWriter(output, true);
			            writer.println(domainName);
			 
			            InputStream input = socket.getInputStream();
			 
			            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			            StringBuilder data = new StringBuilder();
			            while ((socketRes = reader.readLine()) != null) {
			            	data.append(socketRes);
			            	socketResTxtArea.setText(data.toString());
			            	System.out.println(socketRes);
			            }
			        } catch (UnknownHostException ex) {
			        	socketRes = ex.getMessage();
						socketResTxtArea.setText(socketRes);
						ex.printStackTrace();
			 
			        } catch (IOException ioe) {
			        	socketRes = ioe.getMessage();
						socketResTxtArea.setText(socketRes);
						ioe.printStackTrace();
			        }
				
				// showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(),
				// "Registration Successful!", "Welcome " + httpUrlTextField.getText());

			}
		});

	}

	private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.initOwner(owner);
		alert.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}